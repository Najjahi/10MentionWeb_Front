console.log('connecté !');
let divMenu = document.querySelector('.header__nav__menu')
let listMenu = document.querySelectorAll('.header__nav__menu--actives');
console.log(divMenu);
console.log(listMenu);
let divLien = document.querySelector('.header__nav__liens');
console.log(divLien);