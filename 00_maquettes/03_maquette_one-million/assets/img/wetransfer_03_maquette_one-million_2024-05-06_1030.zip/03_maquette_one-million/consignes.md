# Fonts : 
Arial
Roboto Slab // Medium 500

# Couleurs :
Orange :#e74c3c
Bouton rouge hover : #b83e30
Fond icones : rgb(71, 71, 71) / couleurs #fff
Bouton blanc : fond #fff / couleur #e74c3c
Bouton blanc hover : fond rgb(144, 144, 144) / couleur #fff