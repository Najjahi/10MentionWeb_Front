const image1 = document.querySelector('#image1');
const image2 = document.querySelector('#image2');
const image3 = document.querySelector('#image3');
const image4 = document.querySelector('#image4');

// joanne
image1.addEventListener('mouseover',function(){
    image1.classList.add('joanne')
});
image1.addEventListener('mouseout',function(){
    image1.classList.remove('joanne')    
});

//gaston
image2.addEventListener('mouseover',function(){
    image2.classList.add('gaston')
});
image2.addEventListener('mouseout',function(){
    image2.classList.remove('gaston')    
});

//manuel
image3.addEventListener('mouseover',function(){
    image3.classList.add('manuel')
});
image3.addEventListener('mouseout',function(){
    image3.classList.remove('manuel')    
});

//tracy
image4.addEventListener('mouseover',function(){
    image4.classList.add('tracy')
});
image4.addEventListener('mouseout',function(){
    image4.classList.remove('tracy')    
});
        
